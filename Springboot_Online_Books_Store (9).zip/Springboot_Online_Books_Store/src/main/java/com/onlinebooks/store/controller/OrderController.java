package com.onlinebooks.store.controller;

import java.util.List;

import org.apache.commons.logging.LogFactory;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.onlinebooks.store.entity.Orderitems;
import com.onlinebooks.store.service.OrderService;

@RestController
public class OrderController {
	
	

	@Autowired
	private OrderService OrderService;

	@PostMapping("/createdorder")
	public ResponseEntity<String> saveOrder(@RequestBody Orderitems items) {
		
		Orderitems orders = OrderService.createdOrders(items);
		
		if (orders != null) {
			return new ResponseEntity<String>("order saved successfully", HttpStatus.CREATED);
		} else {
			return new ResponseEntity<String>("order not saved", HttpStatus.BAD_REQUEST);
		}

	}
	
	
	@PutMapping("/updateorder")
	public ResponseEntity<String> updatedOrder(@RequestBody Orderitems items) {
		Orderitems orders = OrderService.updatedOrders(items);
		if (orders != null) {
			return new ResponseEntity<String>("order updated  successfully", HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("order not updated", HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/getallorders")
	public ResponseEntity<List<Orderitems>> getallOrder() {
		List<Orderitems> orders = OrderService.getOrders();
		System.err.println(orders);
		if (orders != null) {
			return new ResponseEntity<>(orders, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(orders, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	// delete order api 
	
	
	
	
}
