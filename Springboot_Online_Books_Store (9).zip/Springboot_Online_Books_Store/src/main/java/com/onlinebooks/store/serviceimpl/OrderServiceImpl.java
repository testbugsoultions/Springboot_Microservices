package com.onlinebooks.store.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebooks.store.entity.Orderitems;
import com.onlinebooks.store.exceptions.OrderNotFoundException;
import com.onlinebooks.store.repository.OrderRepository;
import com.onlinebooks.store.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	private OrderRepository orderRepository;

	@Override
	public Orderitems createdOrders(Orderitems items) {
		return orderRepository.save(items);
	}

	@Override
	public Orderitems updatedOrders(Orderitems items) {
		// check the database orderid existed or not
//	 Optional<Orderitems> id = orderRepository.findById(items.getId());
		
//		Orderitems id = orderRepository.findById(items.getId()).orElseThrow(() -> new OrderNotFoundException("Order id not found")); // If not present, throw exception
	
		//if(id.isPresent()) {
		
		Orderitems orderitems = orderRepository.findById(items.getId())
		        .orElseThrow(() -> new OrderNotFoundException("Order id not found"));
//			Orderitems orderitems = id.getId();
			orderitems.setProductName(items.getProductName());
			orderitems.setQuantity(items.getQuantity());
			orderitems.setPrice(items.getPrice());
			orderRepository.save(orderitems);
	//	}else {
//			throw new RuntimeException();
			//throw new OrderNotFoundException("Order id not found");
		//}
		return items;
	}

	@Override
	public List<Orderitems> getOrders() {
		List<Orderitems> all = orderRepository.findAll();
		return all;
	}

}
