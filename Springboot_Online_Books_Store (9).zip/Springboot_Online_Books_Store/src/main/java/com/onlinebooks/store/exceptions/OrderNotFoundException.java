package com.onlinebooks.store.exceptions;

public class OrderNotFoundException extends RuntimeException{

	public OrderNotFoundException( String msg) {
	
		super (msg);
		
	}
	
}
