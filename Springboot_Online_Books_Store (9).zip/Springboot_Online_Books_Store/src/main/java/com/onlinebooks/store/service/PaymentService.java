package com.onlinebooks.store.service;

import com.onlinebooks.store.entity.Payment;

public interface PaymentService {

	 String createPayment(Payment payment);

}
