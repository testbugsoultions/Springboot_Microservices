package com.onlinebooks.store.exceptions;

public class PaymentGatwayException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PaymentGatwayException(String msg) {

		super(msg);

	}

}
