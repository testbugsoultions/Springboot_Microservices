package com.onlinebooks.store.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebooks.store.entity.Orderitems;
import com.onlinebooks.store.repository.OrderRepository;
import com.onlinebooks.store.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	private OrderRepository orderRepository;

	@Override
	public Orderitems createdOrders(Orderitems items) {
		return orderRepository.save(items);
	}

}
