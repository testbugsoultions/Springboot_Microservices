package com.onlinebooks.store.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.onlinebooks.store.entity.Orderitems;
import com.onlinebooks.store.service.OrderService;

@RestController
public class OrderController {

	@Autowired
	private OrderService OrderService;

	@PostMapping("/createdorder")
	public ResponseEntity<String> saveOrder(@RequestBody Orderitems items) {
		Orderitems orders = OrderService.createdOrders(items);
		if (orders != null) {
			return new ResponseEntity<String>("order saved successfully", HttpStatus.CREATED);
		} else {
			return new ResponseEntity<String>("order not saved", HttpStatus.BAD_REQUEST);
		}

	}
	
}
