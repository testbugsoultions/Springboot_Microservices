package com.onlinebooks.store.service;

import com.onlinebooks.store.entity.Orderitems;

public interface OrderService {

	public Orderitems createdOrders(Orderitems items);

}
