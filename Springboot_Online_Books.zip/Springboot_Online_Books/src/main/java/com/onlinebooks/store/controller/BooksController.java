package com.onlinebooks.store.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.onlinebooks.store.model.Product;

@RestController
public class BooksController {

	@PostMapping("/product")
	public String saveProduct(@RequestBody Product p) {
		System.out.println(p);
		// businesss logic
		// cntlr+shift+o
		return "Product saved";
	}

	@GetMapping("/product/{pid}")
	public Product getByProducts(@PathVariable int pid) {
		Product p = null;
		if (pid == 101) {
			p = new Product(101, "HP", 1000);
		} else if (pid == 102) {
			p = new Product(102, "Lennavo", 2000);
		}
		return p;
	}

	@GetMapping("/getAllProducts")
	public List<Product> getAllProdcts() {

		Product p1 = new Product(101, "HP", 1000);
		Product p2 = new Product(102, "Lennavo", 2000);
		// java8
		List<Product> list = Arrays.asList(p1, p2);
		return list;
	}

}
