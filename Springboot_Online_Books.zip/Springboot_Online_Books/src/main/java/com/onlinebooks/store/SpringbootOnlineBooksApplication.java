package com.onlinebooks.store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@Controller + @EnablueAutoConfigartion +@ComponentScan
public class SpringbootOnlineBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootOnlineBooksApplication.class, args);
	}

}
