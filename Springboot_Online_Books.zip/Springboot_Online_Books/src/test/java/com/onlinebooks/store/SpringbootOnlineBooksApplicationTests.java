package com.onlinebooks.store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootOnlineBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
