package com.onlinebooks.store.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.onlinebooks.store.entity.User;
import com.onlinebooks.store.service.UserService;

@RestController
public class RegistrationController {

	@Autowired
	private UserService userService;

	@PostMapping("/userregistartion")
	public ResponseEntity<String> createdReg(@RequestBody User user) {
		User registartion = userService.addRegistartion(user);
		return new ResponseEntity<>("User registered successfully", HttpStatus.OK);

	}
	
	@PostMapping("/login")
	public ResponseEntity<String> createLogin(@RequestBody User user) {
		User checkEmailandPass = userService.addLogin(user);
		if(checkEmailandPass!=null) {
			return new ResponseEntity<>("User Login successfully !!!! Welcome to the OnlineBooks Store", HttpStatus.OK);
		}else {
			return new ResponseEntity<>("Invalid Creditals !!!! Please enter into valid creditals", HttpStatus.BAD_REQUEST);
		}
	}

	}
	