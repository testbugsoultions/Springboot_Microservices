package com.onlinebooks.store.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebooks.store.entity.User;
import com.onlinebooks.store.repository.UserRepo;
import com.onlinebooks.store.service.UserService;

@Service
// service layer devlopeds the business logics
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo userRepo;

	@Override
	public User addRegistartion(User user) {
		User save = userRepo.save(user);
		return save;
	}

	@Override
	public User addLogin(User user) {
		User checkEmailandPass = userRepo.findByEmailandPassword(user.getEmail(), user.getPassword());
		return checkEmailandPass;
	}

	

}
