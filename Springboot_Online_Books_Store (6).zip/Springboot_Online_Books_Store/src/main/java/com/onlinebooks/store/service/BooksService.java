package com.onlinebooks.store.service;

import java.util.List;

import com.onlinebooks.store.entity.Books;

public interface BooksService {
	
	public String upsert(Books  books); // This upsert used to based primary add or update data

	public Books getBooks(Integer bid);

	public List<Books> getAllBooks();

	public String deleteBooks(Integer bid);
	

	
	
	

}
