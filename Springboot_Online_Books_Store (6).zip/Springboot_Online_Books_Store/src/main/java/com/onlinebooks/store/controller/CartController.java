//package com.onlinebooks.store.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.onlinebooks.store.entity.Cart;
//import com.onlinebooks.store.service.CartService;
//
//@RestController
//public class CartController {
//	
//	@Autowired
//	private CartService cartService;
//	
//	
//	     @PostMapping("/{cartId}/add")
//	    public Cart addBookToCart(@PathVariable Long cartId, 
//	                              @RequestParam Long bookId, 
//	                              @RequestParam int quantity) {
//	        return cartService.addBookToCart(cartId, bookId, quantity);
//	    }
//	
//}