//package com.onlinebooks.store.service;
//
//import com.onlinebooks.store.entity.Cart;
//
//public interface CartService {
//
//	public Cart addBookToCart(Long cartId, Long bookId, int quantity);
//
//}
