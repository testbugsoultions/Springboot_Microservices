package com.onlinebooks.store.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebooks.store.entity.Books;
import com.onlinebooks.store.repository.BooksRepository;
import com.onlinebooks.store.service.BooksService;

@Service
public class BooksServiceImpl implements BooksService {

	@Autowired
	BooksRepository booksRepository;

	// This upsert used to based primary add or update data

	@Override
	public String upsert(Books books) {
		Books save = booksRepository.save(books);
		return "saved books";
	}

	@Override
	public Books getBooks(Integer bid) {
		// java 8
		Optional<Books> id = booksRepository.findById(bid);
		if(id.isPresent()) {
			return id.get();
		}
		return null;
	}

	@Override
	public List<Books> getAllBooks() {
		List<Books> list = booksRepository.findAll();
		return list;
	}

	@Override
	public String deleteBooks(Integer bid) {
		if(booksRepository.existsById(bid)){
		  booksRepository.deleteById(bid);
		  return "deleted records";
		}else {
			 return "no records";
		}
	}

}
