package com.onlinebooks.store.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.onlinebooks.store.entity.Files;
import com.onlinebooks.store.repository.FilesRepository;

@RestController
public class FilesController {

	@Autowired
	FilesRepository filesRepository;

	@PostMapping("/upload")
	public ResponseEntity<String> uploadFiles(@RequestParam MultipartFile[] file) throws IOException {
//		step 1 : creating the Arraylist
		List<Files> list = new ArrayList<>();
//       step 2 : iterate the MultipartFile help of foreach loop
		for (MultipartFile fss : file) {
			Files f = new Files();
			f.setType(fss.getContentType());
			f.setName(fss.getOriginalFilename());
			f.setData(fss.getBytes());
			list.add(f);
		}
//		ste3: All files passed to the saveall method
		filesRepository.saveAll(list);
		return new ResponseEntity<>("upload files successfully", HttpStatus.OK);

	}

}
