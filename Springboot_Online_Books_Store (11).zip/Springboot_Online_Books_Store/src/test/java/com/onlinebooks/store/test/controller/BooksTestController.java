package com.onlinebooks.store.test.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.onlinebooks.store.entity.Books;
import com.onlinebooks.store.repository.BooksRepository;
import com.onlinebooks.store.serviceimpl.BooksServiceImpl;

@ExtendWith(MockitoExtension.class)
public class BooksTestController {

	@InjectMocks
	private BooksServiceImpl booksServiceImpl;

	@Mock
	private BooksRepository booksRepository;

	@Test
	public void testfindAllbooks() {

		Books b = new Books();
		b.setId(1);
		b.setName("uma");
		b.setPrice(1000);

		when(booksRepository.findAll()).thenReturn(Arrays.asList(b));

		List<Books> allBooks = booksServiceImpl.getAllBooks();

		assertThat(allBooks).isNotNull();
		verify(booksRepository, times(1)).findAll();

	}

	@Test
	public void testsavebooks() {

		Books b = new Books();
		b.setId(1);
		b.setName("uma");
		b.setPrice(1000);

		when(booksRepository.save(Mockito.any())).thenReturn(b);

		String upsert = booksServiceImpl.upsert(b);

		assertThat(upsert).isNotNull();
		verify(booksRepository, times(1)).save(b);

	}

	@Test
	public void testgetbook() {

		Books b = new Books();
		b.setId(1);
		b.setName("uma");
		b.setPrice(1000);

		when(booksRepository.findById(1)).thenReturn(Optional.of(b));

		Books books = booksServiceImpl.getBooks(1);

		assertThat(books).isNotNull();
		verify(booksRepository, times(1)).findById(1);

	}

}
