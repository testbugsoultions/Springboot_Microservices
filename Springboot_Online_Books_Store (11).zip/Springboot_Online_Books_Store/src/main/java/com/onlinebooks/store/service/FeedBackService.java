package com.onlinebooks.store.service;

import java.util.List;

import com.onlinebooks.store.entity.FeedBack;

public interface FeedBackService {

	public FeedBack createFeedBacks(FeedBack feedBack);

	public List<FeedBack> createFeedBacks();

}
