package com.onlinebooks.store.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "feedback")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FeedBack {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fID")
	private Integer id;
	@Column(name = "EMAIL") // contril+shift+X
	private String email;
	@Column(name = "BOOKNAME")
	private String bookName;
	
	@Column(name = "AUTHOR")
	private String author;
	
	@Column(name = "RATINGS")
	private int ratings;
	@Column(name = "COMMENTS")
	private String comments;

	@Column(name = "CREATED_TIME")
	@CreationTimestamp
	private LocalDateTime createTime;

	@Column(name = "UPDATED_TIME")
	@UpdateTimestamp
	private LocalDateTime updatedTime;

}
