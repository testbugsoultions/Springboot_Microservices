package com.onlinebooks.store.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


//@Data
//@AllArgsConstructor
//@NoArgsConstructor
public class ErrorMessage {
	
	private HttpStatus status;
	private String message;
	private Date date;
	
	
	
	public ErrorMessage(HttpStatus status, String message, Date date) {
		super();
		this.status = status;
		this.message = message;
		this.date = date;
	}
	
	public HttpStatus getStatus() {
		return status;
	}
	public ErrorMessage() {
	
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	
	

}
