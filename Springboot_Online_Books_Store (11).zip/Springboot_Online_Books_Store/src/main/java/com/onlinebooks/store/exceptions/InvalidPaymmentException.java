package com.onlinebooks.store.exceptions;

public class InvalidPaymmentException  extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidPaymmentException(String msg) {
		
		super(msg);
		
	}
	
	
	
}
