package com.onlinebooks.store.dto;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.onlinebooks.store.entity.ExcelFile;

public class Helper {

	public static boolean checkExcel(MultipartFile file) {
		String contentType = file.getContentType();
		if (contentType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
			return true;
		} else {
			return false;
		}
	}

	public static List<ExcelFile> converTExcelFileintoDb(InputStream in) throws IOException {

		List<ExcelFile> list = new ArrayList<>();

		// create the workbook sheet
		XSSFWorkbook work = new XSSFWorkbook(in);

		// workbook inside the sheet [get the sheet]

		XSSFSheet sheet = work.getSheetAt(0);

		int rowNum = 0;
		// sheet inside the rows
		Iterator<Row> rows = sheet.iterator();

		while (rows.hasNext()) {
			Row row = rows.next();
			if (rowNum == 0) {
				rowNum++;
				continue;

			}
			// row inside the columns [get the columns]
			int c = 0;
			Iterator<Cell> cells = row.iterator();
			ExcelFile ex = new ExcelFile();

			while (cells.hasNext()) {
				Cell cell = cells.next();

				switch (c) {
				case 0:
					ex.setId((int) cell.getNumericCellValue());
					break;
				case 1:
					ex.setProductName(cell.getStringCellValue());
					break;
				case 2:
					ex.setPDescriptuon(cell.getStringCellValue());
					break;
				case 3:
					ex.setPrice(cell.getNumericCellValue());
					break;

				default:
					break;
				}
				c++;

			}
			list.add(ex);

		}

		return list;

	}

}
