package com.onlinebooks.store.dto;


// Dto means ----------------------->Data transfer object
import java.util.List;

import org.springframework.http.HttpStatus;

public class ResponeMessage {

	private HttpStatus status;
	private String message;
	private Object data;
	private List<?> list;

	public ResponeMessage(HttpStatus status, String message, Object data, List<?> list) {
		super();
		this.status = status;
		this.message = message;
		this.data = data;
		this.list = list;
	}

//	public ResponeMessage(HttpStatus status, String message, Object data) {
//		super();
//		this.status = status;
//		this.message = message;
//		this.data = data;
//	}
//	

	public ResponeMessage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public List<?> getList() {
		return list;
	}

	public void setList(List<?> list) {
		this.list = list;
	}

}
