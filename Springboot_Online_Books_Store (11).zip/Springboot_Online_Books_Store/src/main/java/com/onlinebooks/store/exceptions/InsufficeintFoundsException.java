package com.onlinebooks.store.exceptions;

public class InsufficeintFoundsException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsufficeintFoundsException(String msg) {
		
		super(msg);
		
	}
	
	
	

}
