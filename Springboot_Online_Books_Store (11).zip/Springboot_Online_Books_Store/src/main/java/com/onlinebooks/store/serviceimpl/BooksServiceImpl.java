package com.onlinebooks.store.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebooks.store.entity.Books;
import com.onlinebooks.store.exceptions.InsufficeintFoundsException;
import com.onlinebooks.store.repository.BooksRepository;
import com.onlinebooks.store.service.BooksService;

@Service
//@Profile(value = {"dev","qa","prod"})
public class BooksServiceImpl implements BooksService {

	@Autowired
	BooksRepository booksRepository;

	// This upsert used to based primary add or update data

	@Override
	public String upsert(Books books) {
//		log.info(" books service add the is started");
		Books save = booksRepository.save(books);
//		log.info(" books service add the is ended");
		return "saved books";
	}

	@Override
	public Books getBooks(Integer bid) {
		// java 8
		Optional<Books> books = booksRepository.findById(bid);
		if(!books.isPresent()) {
//			throw new RuntimeException("InsufficeintFoundsException");
			throw new InsufficeintFoundsException("Book id Not found");
		}
		return books.get();
	}

	@Override
	public List<Books> getAllBooks() {
		List<Books> list = booksRepository.findAll();
		return list;
	}

	@Override
	public String deleteBooks(Integer bid) {
		if(booksRepository.existsById(bid)){
		  booksRepository.deleteById(bid);
		  return "deleted records";
		}else {
			 return "no records";
		}
	}

}
