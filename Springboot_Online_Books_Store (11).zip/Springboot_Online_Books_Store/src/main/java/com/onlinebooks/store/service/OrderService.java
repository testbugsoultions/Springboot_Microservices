package com.onlinebooks.store.service;

import java.util.List;

import com.onlinebooks.store.entity.Orderitems;

public interface OrderService {

	public Orderitems createdOrders(Orderitems items);

	public Orderitems updatedOrders(Orderitems items);

	public List<Orderitems> getOrders();

}
