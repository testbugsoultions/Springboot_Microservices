package com.onlinebooks.store.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

public interface BooksExcelService {

public 	void excefilecreate(MultipartFile file) throws IOException;

}
