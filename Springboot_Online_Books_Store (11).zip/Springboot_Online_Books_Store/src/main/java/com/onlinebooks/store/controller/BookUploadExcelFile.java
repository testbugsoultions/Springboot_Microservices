package com.onlinebooks.store.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.onlinebooks.store.dto.Helper;
import com.onlinebooks.store.dto.ResponeMessage;
import com.onlinebooks.store.service.BooksExcelService;

@RestController
@RequestMapping("/api")
public class BookUploadExcelFile {

	@Autowired
	BooksExcelService booksExcelService;

	@PostMapping("/uploadExcel")
	public ResponseEntity<ResponeMessage> createdExcel(@RequestParam MultipartFile file) throws IOException {

		if (Helper.checkExcel(file)) {
			booksExcelService.excefilecreate(file);
			return ResponseEntity.ok(new ResponeMessage(HttpStatus.OK, "excele file upload into database succesfully", file.getOriginalFilename(), null));
		} else {

			return ResponseEntity.ok(new ResponeMessage(HttpStatus.BAD_REQUEST, "please upload the files", file.getOriginalFilename(), null));


		}
	}
}
