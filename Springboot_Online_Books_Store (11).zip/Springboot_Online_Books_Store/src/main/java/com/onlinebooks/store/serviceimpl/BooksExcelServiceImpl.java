package com.onlinebooks.store.serviceimpl;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.onlinebooks.store.dto.Helper;
import com.onlinebooks.store.entity.ExcelFile;
import com.onlinebooks.store.repository.BooksExcelRepository;
import com.onlinebooks.store.service.BooksExcelService;

@Service
public class BooksExcelServiceImpl implements BooksExcelService {

	@Autowired
	BooksExcelRepository booksExcelRepository;

	@Override
	public void excefilecreate(MultipartFile file) throws IOException {

		List<ExcelFile> listofFiles = Helper.converTExcelFileintoDb(file.getInputStream());
		booksExcelRepository.saveAll(listofFiles);

	}

}
