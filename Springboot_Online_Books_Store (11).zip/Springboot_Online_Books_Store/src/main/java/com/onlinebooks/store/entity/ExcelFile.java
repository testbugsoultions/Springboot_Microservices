package com.onlinebooks.store.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class ExcelFile {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer id;

	@Column(name = "PRODUCTNAME")
	private String productName;

	@Column(name = "PDESCRIPTUON")
	private String pDescriptuon;

	@Column(name = "PRICE")
	private Double price;
	
	@Column(name = "CREATED_TIME")
	@CreationTimestamp
	private LocalDateTime createTime;

	// cntrl +shift + x

	@Column(name = "UPDATED_TIME")
	@UpdateTimestamp
	private LocalDateTime updatedTime;

}
