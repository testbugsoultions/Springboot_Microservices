package com.onlinebooks.store.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.onlinebooks.store.entity.Books;
import com.onlinebooks.store.service.BooksService;

@RestController
public class BooksController {

	@Autowired
	private BooksService booksService;

	@PostMapping("/addBook")
	public ResponseEntity<String> addBooks(@RequestBody Books books) {
//		log.info(" books controller  is started");
		String upsert = booksService.upsert(books);
//		log.info(" books controller  is ended");
		return new ResponseEntity<>("books inserted successfully", HttpStatus.CREATED); // 201

	}

	@PutMapping("/updateBook")
	public ResponseEntity<String> updateBooks(@RequestBody Books books) {
		String upsert = booksService.upsert(books);
		return new ResponseEntity<>("books update successfully", HttpStatus.OK); // 200
	}

	@GetMapping("/getByBook/{bid}")
	public ResponseEntity<Books> getByBooks(@PathVariable Integer bid) {
		Books books = booksService.getBooks(bid);
		return new ResponseEntity<>(books, HttpStatus.OK);
	}

	@GetMapping("/getAllBooks")
	public ResponseEntity<List<Books>> getByAllBooks() {
		List<Books> allBooks = booksService.getAllBooks();
		return new ResponseEntity<>(allBooks, HttpStatus.OK); // 200
	}
	
	@DeleteMapping("/deleteBook/{bid}")
	public ResponseEntity<String> deleteByBooks(@PathVariable Integer bid) {
		String deleteBooks = booksService.deleteBooks(bid);
		return new ResponseEntity<>(deleteBooks, HttpStatus.OK); // 200
	}
	

}
