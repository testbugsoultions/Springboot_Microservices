package com.onlinebooks.store.exceptions;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class BooksGlobalExceptionHandler {

	@ExceptionHandler(value = BookIdNotFoundException.class)
	public ResponseEntity<ResponseMessage> handleExceptions() {
		ResponseMessage res = new ResponseMessage(HttpStatus.NOT_FOUND, "Book id Not Found", new Date());
		return new ResponseEntity<ResponseMessage>(res, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(value = IdNotFoundException.class)
	public ResponseEntity<ResponseMessage> handleglobal() {
		ResponseMessage res = new ResponseMessage(HttpStatus.BAD_REQUEST, " id Not Found", new Date());
		return new ResponseEntity<ResponseMessage>(res, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> internalServerException() {

		HashMap<String, Object> map = new HashMap<>();
		map.put("timestamp", LocalDateTime.now());
		map.put("status", HttpStatus.INTERNAL_SERVER_ERROR);
		map.put("error", "internalserver error");
		map.put("Message", "An un-excpeted error occured");
		return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
