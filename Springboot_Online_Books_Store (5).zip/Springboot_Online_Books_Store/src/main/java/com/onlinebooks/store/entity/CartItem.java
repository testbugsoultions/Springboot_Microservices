//package com.onlinebooks.store.entity;
//
//import java.awt.print.Book;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.ManyToOne;
//
//@Entity
//public class CartItem {
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private Long id;
//
//	@ManyToOne
//	@JoinColumn(name = "cart_id")
//	private Cart cart;
//
//	@ManyToOne
//	@JoinColumn(name = "book_id")
//	private Books book;
//
//	private int quantity;
//
//	public CartItem() {
//	}
//
//	public CartItem(Books book, int quantity, Cart cart) {
//		this.book = book;
//		this.quantity = quantity;
//		this.cart = cart;
//	}
//
//	// Getters and Setters
//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}
//
//	public Cart getCart() {
//		return cart;
//	}
//
//	public void setCart(Cart cart) {
//		this.cart = cart;
//	}
//
//	public Books getBook() {
//		return book;
//	}
//
//	public void setBook(Books book) {
//		this.book = book;
//	}
//
//	public int getQuantity() {
//		return quantity;
//	}
//
//	public void setQuantity(int quantity) {
//		this.quantity = quantity;
//	}
//}
