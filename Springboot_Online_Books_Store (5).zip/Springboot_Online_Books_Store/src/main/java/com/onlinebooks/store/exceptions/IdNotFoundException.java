package com.onlinebooks.store.exceptions;

public class IdNotFoundException extends RuntimeException {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IdNotFoundException(String str) {
		
		super(str);
		
	}
	
}
