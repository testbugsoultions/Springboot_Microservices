//package com.onlinebooks.store.serviceimpl;
//
//import java.awt.print.Book;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.onlinebooks.store.entity.Books;
//import com.onlinebooks.store.entity.Cart;
//import com.onlinebooks.store.entity.CartItem;
//import com.onlinebooks.store.repository.BooksRepository;
//import com.onlinebooks.store.repository.CartRepository;
//import com.onlinebooks.store.service.CartService;
//
//@Service
//public class CartServiceImpl implements CartService {
//	
//	@Autowired
//	private CartRepository cartRepository;
//	
//	@Autowired
//	BooksRepository bookRepository;
//	
//	public Cart getCart(Long cartId) {
//        return cartRepository.findById(cartId)
//                .orElseThrow(() -> new RuntimeException("Cart not found"));
//    }
//	
//
//	@Override
//	public Cart addBookToCart(Long cartId, Long bookId, int quantity) {
//		  Cart cart = getCart(cartId);
//	        Books book = bookRepository.findById(bookId)
//	                .orElseThrow(() -> new RuntimeException("Book not found"));
//
////	        Optional<CartItem> existingItem = cart.getCartItems().stream()
////	                .filter(item -> item.getBook().getId().equals(bookId))
////	                .findFirst();
//	        
//	        CartItem existingItem = null;
//	        for (CartItem item : cart.getCartItems()) {
//	            if (item.getBook() != null && item.getBook().getId().equals(bookId)) {
//	                existingItem = item;
//	                break;  // Exit the loop once the item is found
//	            }
//	        }
//
//	        
//
//	        if (existingItem.isPresent()) {
//	            CartItem cartItem = existingItem.get();
//	            cartItem.setQuantity(cartItem.getQuantity() + quantity);
//	        } else {
//	            CartItem cartItem = new CartItem(book, quantity, cart);
//	            cart.getCartItems().add(cartItem);
//	        }
//
//	        cart.calculateTotalPrice();
//	        return cartRepository.save(cart);
//	    }
//
//		
//	}
