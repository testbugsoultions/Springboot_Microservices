package com.onlinebooks.store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@configartion + @EnableAutoconfigartion + @Componentscan
public class SpringbootOnlineBooksStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootOnlineBooksStoreApplication.class, args);
	}

}
