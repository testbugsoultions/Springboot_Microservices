package com.onpassive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRealtimeDockerExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootRealtimeDockerExampleApplication.class, args);
	}

}
