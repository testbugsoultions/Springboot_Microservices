package com.onpassive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRealtimeDockerExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
