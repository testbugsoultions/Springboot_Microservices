package com.onlinebooks.store.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExample {

	@ExceptionHandler(value = InsufficeintFoundsException.class)
	public ResponseEntity<ErrorMessage> insuffFounds() {
		ErrorMessage res = new ErrorMessage(HttpStatus.NOT_FOUND, "BookId Not Found", new Date());
		return new ResponseEntity<ErrorMessage>(res, HttpStatus.NOT_FOUND);

	}
	
	@ExceptionHandler(value = OrderNotFoundException.class)
	public ResponseEntity<ErrorMessage> orderNotfound() {
		ErrorMessage res = new ErrorMessage(HttpStatus.BAD_REQUEST, "order Not Found", new Date());
		return new ResponseEntity<ErrorMessage>(res, HttpStatus.BAD_REQUEST);

	}
	
	
	

}
