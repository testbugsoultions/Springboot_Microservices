package com.onlinebooks.store.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.onlinebooks.store.dto.ResponeMessage;
import com.onlinebooks.store.entity.FeedBack;
import com.onlinebooks.store.service.FeedBackService;

@RestController
public class FeedBackController {

	@Autowired
	private FeedBackService feedBackService;

	@PostMapping("/feedback")
	public ResponseEntity<ResponeMessage> createdFeedBack(@RequestBody FeedBack feedBack) {
		FeedBack fback = feedBackService.createFeedBacks(feedBack);
		return ResponseEntity.ok(new ResponeMessage(HttpStatus.CREATED, "feedback created sucessfully", fback, null));

	}
	
	@GetMapping("/getAllFeedback")
	public ResponseEntity<ResponeMessage> getFeedBacks() {
		 List<FeedBack> list = feedBackService.createFeedBacks();
		return ResponseEntity.ok(new ResponeMessage(HttpStatus.OK, "feedback retrive sucessfully", null, list));

	}
	
	
	
	
	
	

}
