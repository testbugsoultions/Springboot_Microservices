package com.onlinebooks.store.serviceimpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.onlinebooks.store.entity.Payment;
import com.onlinebooks.store.exceptions.InvalidPaymmentException;
import com.onlinebooks.store.exceptions.PaymentGatwayException;
import com.onlinebooks.store.repository.PaymentRepo;
import com.onlinebooks.store.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {
	
	
	

	@Autowired
	private PaymentRepo paymentRepo;


	    @Transactional(rollbackFor = Exception.class)  // Ensures rollback on any Exception
	    @Override
	    public String createPayment(Payment payment) {
	        try {
	        	
//	        	step 2
	            // Perform validation on payment details    let us assume  (-9000)  or (0000)
	            validatePayment(payment);

	            // Process the payment
	            boolean processPayment = processPayment(payment);
                // step 1
	            if (processPayment) {
	                payment.setStatus("SUCCESS");
	                paymentRepo.save(payment);  // If successful, commit the transaction
	                return "Payment processed successfully";
	            } else {
	                payment.setStatus("FAILURE");
	                paymentRepo.save(payment);  // Save the failure status
	                return "Payment process failed: Unable to process payment at this time";
	            }

	        } catch (InvalidPaymmentException e) {
	            payment.setStatus("FAILURE");
	            paymentRepo.save(payment);  // Save the failure status before rollback
	            throw e;  // Transaction will be rolled back due to the exception

	        } catch (PaymentGatwayException e) {
	            payment.setStatus("FAILURE");
	            paymentRepo.save(payment);  // Save the failure status before rollback
	            throw e;  // Transaction will be rolled back

	        } catch (DataAccessException e) {  // Handle database-related exceptions
	            payment.setStatus("FAILURE");
	            // No need to explicitly save because the transaction will be rolled back
	            throw e;  // This will trigger a rollback
	        } catch (Exception e) {
	            payment.setStatus("FAILURE");
	            paymentRepo.save(payment); 
	            // Save the failure status before rollback
	            throw new RuntimeException("Unexpected error during payment processing", e);
	            
	        }
	    }

	    // Mock method to simulate payment processing
	    private boolean processPayment(Payment payment) throws PaymentGatwayException {
	        // Simulate payment success or failure based on some logic
	        if (payment.getAmount() <= 0) {
	            throw new InvalidPaymmentException("Invalid payment amount");
	        }

	        // Simulate payment gateway failure for certain conditions (e.g., network issue)
	        if ("CREDIT_CARD".equals(payment.getPaymentMethod()) && payment.getAmount() > 7000) {
	            throw new PaymentGatwayException("Payment gateway error for large transactions");
	        }
	        

	        // Return true if payment is successful
	        return true;
	    }
	    
	    
	    private void validatePayment(Payment payment) throws InvalidPaymmentException {
			if (payment.getAmount() <= 0) {
				throw new InvalidPaymmentException("Invalid amount specified.");
			}

		}
	}

