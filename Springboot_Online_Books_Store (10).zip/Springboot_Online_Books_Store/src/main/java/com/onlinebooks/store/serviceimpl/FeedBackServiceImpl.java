package com.onlinebooks.store.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebooks.store.entity.FeedBack;
import com.onlinebooks.store.repository.FeedBackRepository;
import com.onlinebooks.store.service.FeedBackService;

@Service
public class FeedBackServiceImpl implements FeedBackService{

	@Autowired
	private FeedBackRepository feedBackRepository;
	
	@Override
	public FeedBack createFeedBacks(FeedBack feedBack) {
		return feedBackRepository.save(feedBack);
	}

	@Override
	public List<FeedBack> createFeedBacks() {
	
		return feedBackRepository.findAll();
	}

}
