package com.onlinebooks.store.service;

import com.onlinebooks.store.entity.User;


public interface UserService {

	public User addRegistartion(User user);

	public User addLogin(User user);

	
	
	

}
